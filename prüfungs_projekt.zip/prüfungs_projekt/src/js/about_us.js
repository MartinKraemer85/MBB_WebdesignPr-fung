"use strict";

const elements = {};

const domEventHandler = {
    handleSocialClick: (el) => handleSocialClick(el)
}

const domMapping = () => {
    // Intersection elements
    addIntersectioNArticle();
};

// =======================
// Init Function
// =======================

const init = () => {
    addDomFunctions(domEventHandler);
    domMapping();
    addObserverToSection();
};

// =======================
// DOM Ready Handler
// =======================

document.addEventListener("DOMContentLoaded", () => {
    init();
});