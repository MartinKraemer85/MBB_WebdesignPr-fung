
"use strict";

const elements = {}

const toggleRecipeVisibility = (el, show) => {
    el.classList.toggle("show-recipe", show);
    el.classList.toggle("hide-recipe", !show);
};

const sliderLeft = (slider) => {
    toggleRecipeVisibility(slider.articles[slider.counter], false)

    slider.counter--;
    if (slider.counter < 0) slider.counter = slider.articles.length - 1;

    toggleRecipeVisibility(slider.articles[slider.counter], true)
}

const sliderRight = (slider) => {
    toggleRecipeVisibility(slider.articles[slider.counter], false)

    slider.counter++;
    if (slider.counter >= slider.articles.length) slider.counter = 0;

    toggleRecipeVisibility(slider.articles[slider.counter], true)
}


const domMapping = () => {
    var slider = document.getElementById("momo-slider");
    var articles = slider.children;
    elements.momo = { articles: articles, counter: 0 };

    slider = document.getElementById("bocchi-slider");
    articles = slider.children;

    elements.bocchi = { articles: articles, counter: 0 };

    slider = document.getElementById("bertram-slider");
    articles = slider.children;

    elements.bertram = { articles: articles, counter: 0 };

    // Intersection elements
    addIntersectioNArticle();
};

// =======================
// general stuff
// =======================
const equalizeRecipeHeights = () => {
    const cards = document.querySelectorAll('.content-wrapper');
    let maxHeight = 0;

    cards.forEach(card => {
        card.style.minHeight = 'auto'; // reset
        const height = card.offsetHeight;
        if (height > maxHeight) maxHeight = height;
    });

    cards.forEach(card => {
        card.style.minHeight = `${maxHeight}px`;
    });
    console.log("resize");

};


// =======================
// Init Function
// =======================

const hideSliderCards = (articles) => Array.from(articles).forEach((element, index) => {
    index > 0 ? element.classList.add("hide-recipe") : element.classList.add("show-recipe");
});

const init = () => {
    domMapping();

    // initial slider setting
    hideSliderCards(elements.momo.articles);
    hideSliderCards(elements.bocchi.articles);
    hideSliderCards(elements.bertram.articles);

    document.querySelectorAll('.nav-chevron.left').forEach(el => {
        el.addEventListener('click', () => {
            const name = el.getAttribute('name');
            if (name === 'momo') {
                sliderLeft(elements.momo);
            }

            if (name === 'bocchi') {
                sliderLeft(elements.bocchi);
            }


            if (name === 'bertram') {
                sliderLeft(elements.bertram);
            }
        });
    });

    document.querySelectorAll('.nav-chevron.right').forEach(el => {
        el.addEventListener('click', () => {
            const name = el.getAttribute('name');
            if (name === 'momo') {
                sliderRight(elements.momo);
            }

            if (name === 'bocchi') {
                sliderRight(elements.bocchi);
            }

            if (name === 'bertram') {
                sliderRight(elements.bertram);
            }
        });
    });
};

// =======================
// DOM Ready Handler
// =======================

document.addEventListener("DOMContentLoaded", () => {
    init();
});

window.addEventListener('load', equalizeRecipeHeights);
window.addEventListener('resize', equalizeRecipeHeights);