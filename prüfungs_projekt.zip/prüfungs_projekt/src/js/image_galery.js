"use strict";

const elements = {};

const handleImageClick = (el) => {
    setTimeout(() => {
        const images = elements.slider.images;
        for (let i = 0; i < images.length; i++) {
            if (images[i] === el) {
                elements.slider.counter = i;
                break;
            }
        }

        elements.modal.classList.remove("hidden");

        const modalImage = document.createElement("img");
        modalImage.src = el.src;
        modalImage.alt = el.alt;

        modalImage.style.pointerEvents = "none";
        modalImage.classList.add("modal-img");
        modalImage.onmouseover = null;
        modalImage.onclick = null;

        // Modal-Inhalt ersetzen
        elements.modalImg.innerHTML = ""; // Clear previous image
        elements.modalImg.appendChild(modalImage);
    }, 100);

}
const handleOverlayClick = (event) => {
    if (event.target === elements.modal) {
        elements.modal.classList.add("hidden");
    }
}

const cloneNode = (image) => {
    const clonedImage = image.cloneNode(true);
    clonedImage.classList.add("modal-img");
    clonedImage.style.pointerEvents = "none";
    clonedImage.onmouseover = null;
    clonedImage.onclick = null;

    return clonedImage;
}

const chevronLeft = () => {
    elements.slider.counter--;
    if (elements.slider.counter < 0) elements.slider.counter = elements.slider.imageCount - 1;
    const currentImage = elements.slider.images[elements.slider.counter]

    elements.modalImg.innerHTML = ""; // Clear previous image
    elements.modalImg.appendChild(cloneNode(currentImage));
}

const chevronRight = () => {
    elements.slider.counter++;
    if (elements.slider.counter >= elements.slider.imageCount) elements.slider.counter = 0;
    const currentImage = elements.slider.images[elements.slider.counter]

    elements.modalImg.innerHTML = ""; // Clear previous image
    elements.modalImg.appendChild(cloneNode(currentImage));
}

const domMapping = () => {
    elements.modal = document.getElementById("modal");
    elements.modalImg = document.getElementById("modal-img");

    var images = document.getElementById("image-wrapper");
    elements.slider = { images: images.children, counter: 0, imageCount: images.children.length };
};


// =======================
// Init Function
// =======================

const init = () => {
    domMapping();
};

// =======================
// DOM Ready Handler
// =======================

document.addEventListener("DOMContentLoaded", () => {
    init();
});