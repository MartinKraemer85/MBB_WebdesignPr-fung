"use strict";

const domEventHandler = {
    handleSocialClick: (el) => handleSocialClick(el)
}

// =======================
// Init Function
// =======================

const init = () => {
    addDomFunctions(domEventHandler);
};

// =======================
// DOM Ready Handler
// =======================

document.addEventListener("DOMContentLoaded", () => {
    init();
});