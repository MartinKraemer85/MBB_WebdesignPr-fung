"use strict";

const handleFormSubmit = (e) => {
    e.preventDefault();
    alert("Email wurde gesendet, alsbald werden wir uns melden");
}


// =======================
// Init Function
// =======================

const init = () => {
};

// =======================
// DOM Ready Handler
// =======================

document.addEventListener("DOMContentLoaded", () => {
    init();
});