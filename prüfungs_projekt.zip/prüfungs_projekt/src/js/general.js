"use strict";

const addDomFunctions = (eventhandler = {}) => {
    Object.keys(eventhandler).forEach(funcName => {
        window[funcName] = eventhandler[funcName];
    });
};

const handleSocialClick = (el) => {
    alert(`Wir sind gerade mal 2 Jahre alt!\n\ wir dürfen noch nicht auf ${el.name.toUpperCase()} herumgeistern!`)
}


const observerOptions = {
    root: null, // viewport
    rootMargin: '0px',
    threshold: 0.5 // at least 50% visible
};


// Used to check which article is the last one that was scrolled over
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        const id = entry.target.getAttribute('id');
        // get the chevron with the id as target
        const chevron = document.querySelector(`.chevron a[href="#${id}"]`)?.parentElement;

        if (entry.isIntersecting) {
            elements.chevrons.forEach(c => c.classList.remove('active'));
            if (chevron) chevron.classList.add('active');
        }
    });
}, observerOptions);

const addIntersectioNArticle = () => {
    elements.article = document.querySelectorAll('article[id]');
    elements.chevrons = document.querySelectorAll('aside .chevron');
}



const setActiveNavigation = () => {
    const filename = window.location.pathname.split("/").pop();
    const link = document.querySelector(`.navigation a[href="./${filename}"]`)?.parentElement
    if (link) link.classList.add("active");
}

document.addEventListener("DOMContentLoaded", () => {
    setActiveNavigation();
});
